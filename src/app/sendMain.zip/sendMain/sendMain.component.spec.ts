/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { SendMainComponent } from './sendMain.component';

describe('SendMainComponent', () => {
  let component: SendMainComponent;
  let fixture: ComponentFixture<SendMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
