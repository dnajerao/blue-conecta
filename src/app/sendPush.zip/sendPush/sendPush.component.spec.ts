/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { SendPushComponent } from './sendPush.component';

describe('SendPushComponent', () => {
  let component: SendPushComponent;
  let fixture: ComponentFixture<SendPushComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SendPushComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SendPushComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
